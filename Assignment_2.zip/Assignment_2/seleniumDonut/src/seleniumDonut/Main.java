
package seleniumDonut;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;

public class Main {

	
	public static void main(String[] args) throws InterruptedException{
		
		
		System.setProperty("webdriver.chrome.driver","/Users/asus/Desktop/selenium/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		String baseUrl = "http://localhost/donutshop/admin/";
			
		driver.get(baseUrl);
	
		
		WebElement adminPanel = driver.findElement(By.xpath("/html/body/a"));
		adminPanel.click();
		
		//Getting into the add-product.php
		WebElement addProductButton = driver.findElement(By.xpath("/html/body/div/div/a"));
		addProductButton.click();
		
		
		
		//Checking if its on correct page 
		
		String addingProductTitle = driver.getTitle();
		System.out.println("Title of the webpage: " +addingProductTitle);
		
		String expectedProductTitle = "Add Product";
		
		if(addingProductTitle.contentEquals(expectedProductTitle)) {
			System.out.println("Test Passed");
			
			
			WebElement productNameBox = driver.findElement(By.id("productName"));
			productNameBox.sendKeys("Marble-Frosted Donut");
			
			
			WebElement productDescriptionBox = driver.findElement(By.id("productDescription"));
			productDescriptionBox.sendKeys("A little chocolate, a little vanilla�a whole lotta sweet.");
			
			
			WebElement productPriceBox = driver.findElement(By.id("productPrice"));
			productPriceBox.sendKeys("4.25");
			
			
			WebElement addingProductButton = driver.findElement(By.xpath("/html/body/div/div/form/button"));
			addingProductButton.click();
			
			
			
			WebElement goBackButton = driver.findElement(By.xpath("/html/body/div/div/a"));
			goBackButton.click();
		}
		else {
			System.out.println("Test Fail");
		}

		
		Thread.sleep(2000);  
		driver.close();
		

		   
	}
}
