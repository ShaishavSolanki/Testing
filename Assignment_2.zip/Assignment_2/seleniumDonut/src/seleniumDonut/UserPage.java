package seleniumDonut;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class UserPage {

	public static void main(String[] args) throws InterruptedException{
		
		

	System.setProperty("webdriver.chrome.driver","/Users/asus/Desktop/selenium/chromedriver.exe");
	WebDriver driver = new ChromeDriver();
	
	String baseUrl = "http://localhost/donutshop/public/";
		
	driver.get(baseUrl);
	
	String homePageTitle = driver.getTitle();
	System.out.println("Title of the webpage: " +homePageTitle);
	
	String expectedProductTitle = "Donut Shop!";
	
	if(homePageTitle.contentEquals(expectedProductTitle)) {
		System.out.println("Test Passed");
			
		WebElement adminPanel = driver.findElement(By.xpath("/html/body/nav/p[4]/a"));
		adminPanel.click();
		}
		else {
			System.out.println("Test Fail");
		}
		


	
	
	
	}
}

