<?php
	include("header.php");
?>

    <!-- Title -->
    <section class="section">
      <div class="container">
        <h1 class="title has-text-centered">The Magic Donut Shop</h1>
        <h2 class="subtitle has-text-centered">
          We make super awesome donuts!
        </h2>
				<img src="images/pink-donut.jpg" style="display:block; margin:0 auto;">
      </div>
    </section>

		<script type="text/javascript">
    </script>
  </body>
</html>
