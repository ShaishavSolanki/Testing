<?php
	// about us
	include("header.php");
?>

<h1> ABOUT US </h1>
